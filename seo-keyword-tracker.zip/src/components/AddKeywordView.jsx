import { useState } from "react";
import { monthKeys, monthLabel, formatPosition } from "../data";

export default function AddKeywordView({
  onBack,
  onAdd,
  defaultDomain = "techsphere.io",
  availableCategories = ["Core Product", "Guides", "Integrations", "Pricing", "Enterprise"],
}) {
  const months = monthKeys(6);
  const currentMonthKey = months.at(-1);

  const [form, setForm] = useState({
    keyword: "",
    url: "",
    position: "3",
    volume: "1400",
    difficulty: "35",
    group: availableCategories[0] || "Core Product",
    notRanking: false,
    hasPastRankings: false,
  });

  const [pastMonthsData, setPastMonthsData] = useState(() => {
    return Object.fromEntries(months.map((m) => [m, ""]));
  });

  const handleMonthChange = (monthKey, val) => {
    setPastMonthsData((prev) => ({
      ...prev,
      [monthKey]: val,
    }));
  };

  const handleSubmit = (e, keepOpen = false) => {
    if (e) e.preventDefault();
    if (!form.keyword.trim()) return;

    const pos = form.notRanking ? 101 : Math.min(100, Math.max(1, parseInt(form.position, 10) || 50));
    const vol = Math.max(0, parseInt(form.volume, 10) || 1000);
    const diff = Math.min(100, Math.max(1, parseInt(form.difficulty, 10) || 35));

    // Construct 30-day history
    const history = Array(30).fill(pos);

    // Construct monthly data
    const monthly = {};
    months.forEach((m) => {
      if (m === currentMonthKey) {
        monthly[m] = pos;
      } else if (form.hasPastRankings && pastMonthsData[m]) {
        monthly[m] = Number(pastMonthsData[m]);
      }
    });

    const newKeyword = {
      id: Date.now(),
      keyword: form.keyword.trim(),
      group: form.group.trim() || "General",
      url: form.url.trim() || `https://${defaultDomain}/`,
      volume: vol,
      difficulty: diff,
      history,
      monthly,
    };

    onAdd(newKeyword);

    if (keepOpen) {
      setForm((prev) => ({
        ...prev,
        keyword: "",
        url: "",
        position: "3",
        volume: "1400",
        notRanking: false,
      }));
      setPastMonthsData(Object.fromEntries(months.map((m) => [m, ""])));
    } else {
      onBack();
    }
  };

  return (
    <div className="add-keyword-page">
      <div className="add-keyword-topbar">
        <div>
          <button className="back-link" onClick={onBack}>
            ← Back to Keyword Intelligence
          </button>
          <h1 className="page-title">Add New Keyword</h1>
          <p className="page-subtitle">
            Track a target query and monitor its SERP rankings in real-time.
          </p>
        </div>

        <div className="domain-badge-card">
          <div className="domain-avatar">
            {defaultDomain.charAt(0).toUpperCase()}
          </div>
          <div className="domain-info">
            <span className="domain-name">{defaultDomain}</span>
            <span className="domain-target">Active Project</span>
          </div>
        </div>
      </div>

      <div className="config-card">
        <div className="config-header">
          <div>
            <h2 className="config-title">Keyword Configuration</h2>
            <p className="config-desc">
              Configure query parameters, target landing URL, category, and initial position.
            </p>
          </div>
        </div>

        <form onSubmit={(e) => handleSubmit(e, false)} className="config-form">
          {/* Keyword Query */}
          <div className="form-group">
            <label className="form-label">
              Keyword Query <span className="req">*</span>
            </label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. distributed sql query engine"
              required
              value={form.keyword}
              onChange={(e) => setForm({ ...form, keyword: e.target.value })}
            />
          </div>

          {/* Category / Group */}
          <div className="form-group">
            <label className="form-label">
              Category / Group <span className="req">*</span>
            </label>
            <div style={{ display: "flex", gap: 8 }}>
              <input
                type="text"
                list="category-suggestions"
                className="form-input"
                placeholder="e.g. Core Product, Guides, Integrations..."
                required
                value={form.group}
                onChange={(e) => setForm({ ...form, group: e.target.value })}
              />
              <datalist id="category-suggestions">
                {availableCategories.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>
          </div>

          {/* Target Landing Page URL (Optional) */}
          <div className="form-group">
            <label className="form-label">
              Target Landing Page URL <span className="muted" style={{ fontWeight: 400 }}>(Optional)</span>
            </label>
            <input
              type="text"
              className="form-input"
              placeholder={`https://${defaultDomain}/`}
              value={form.url}
              onChange={(e) => setForm({ ...form, url: e.target.value })}
            />
          </div>

          {/* Position & Search Volume Grid */}
          <div className="form-grid-2">
            <div className="form-group">
              <label className="form-label">
                Current Position / Rank (1-100) <span className="req">*</span>
              </label>
              <div className="input-affix-wrapper">
                <input
                  type="number"
                  min="1"
                  max="100"
                  className="form-input"
                  placeholder="e.g. 3"
                  disabled={form.notRanking}
                  value={form.notRanking ? "" : form.position}
                  onChange={(e) => setForm({ ...form, position: e.target.value })}
                />
                <span className="input-suffix">#Rank</span>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">
                Monthly Search Volume <span className="req">*</span>
              </label>
              <div className="input-affix-wrapper">
                <input
                  type="number"
                  min="0"
                  className="form-input"
                  placeholder="e.g. 1400"
                  required
                  value={form.volume}
                  onChange={(e) => setForm({ ...form, volume: e.target.value })}
                />
                <span className="input-suffix">vol/mo</span>
              </div>
            </div>
          </div>

          {/* Not ranking checkbox */}
          <div className="form-checkbox-row">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={form.notRanking}
                onChange={(e) => setForm({ ...form, notRanking: e.target.checked })}
              />
              <span>Not ranking yet (outside top 100)</span>
            </label>
          </div>

          {/* Monthly Position History Section */}
          <div className="monthly-history-box">
            <div className="monthly-history-header">
              <div className="monthly-history-title-wrap">
                <span className="monthly-icon">⏱</span>
                <span className="monthly-history-title">
                  Monthly Position History (6-Month Horizon)
                </span>
              </div>
              <label className="checkbox-label compact">
                <input
                  type="checkbox"
                  checked={form.hasPastRankings}
                  onChange={(e) => setForm({ ...form, hasPastRankings: e.target.checked })}
                />
                <span>I already have past rankings (backfill)</span>
              </label>
            </div>

            <p className="monthly-history-subtitle">
              Current month reflects today's rank. Previous months start empty for new keywords.
            </p>

            {/* Months Pills Grid */}
            <div className="months-horizon-grid">
              {months.map((m) => {
                const isCurrent = m === currentMonthKey;
                return (
                  <div key={m} className={`month-horizon-card ${isCurrent ? "current" : ""}`}>
                    <div className="month-horizon-label">
                      {monthLabel(m)}
                      {isCurrent && <span className="live-pill">Live</span>}
                    </div>
                    {isCurrent ? (
                      <div className="month-horizon-val current-val">
                        {form.notRanking ? ">100" : form.position ? formatPosition(form.position) : "–"}
                      </div>
                    ) : form.hasPastRankings ? (
                      <input
                        type="number"
                        min="1"
                        max="100"
                        placeholder="–"
                        className="month-horizon-input"
                        value={pastMonthsData[m]}
                        onChange={(e) => handleMonthChange(m, e.target.value)}
                      />
                    ) : (
                      <div className="month-horizon-val empty-val">–</div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="monthly-info-note">
              <span className="info-icon">ⓘ</span>
              <span>
                Previous months have no data yet because tracking starts today. You can import historical data anytime via CSV or Google Search Console.
              </span>
            </div>
          </div>

          {/* Form Actions Footer */}
          <div className="form-actions-footer">
            <button type="button" className="btn-cancel" onClick={onBack}>
              Cancel
            </button>
            <div className="form-actions-right">
              <button
                type="button"
                className="btn-secondary-action"
                onClick={(e) => handleSubmit(e, true)}
              >
                <span>⊕</span> Add & Add Another
              </button>
              <button type="submit" className="btn-primary-action">
                Add Keyword
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
