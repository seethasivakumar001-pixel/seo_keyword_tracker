import { useEffect, useMemo, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { initialKeywords, getDifficultyInfo, formatVolume, formatPosition } from "./data";
import Monthly from "./components/Monthly";
import AddKeywordView from "./components/AddKeywordView";

const STORE = "seo-keywords-v3";
const DELETED_STORE = "seo-deleted-keywords-v3";
const PROJECTS_STORE = "seo-projects-v3";
const ACTIVE_PROJECT_STORE = "seo-active-project-v3";
const CATEGORIES_STORE = "seo-categories-v3";

const cur = (k) => k.history.at(-1);
const delta = (k) => (k.history.length > 7 ? k.history.at(-8) - cur(k) : 0); // + = moved up over 7 days

const initialProjects = [
  { id: "p1", name: "TechSphere Cloud", domain: "techsphere.io" },
  { id: "p2", name: "DataMesh Systems", domain: "datamesh.io" },
];

const initialCategories = ["Core Product", "Guides", "Integrations", "Pricing", "Enterprise"];

function Spark({ data, up }) {
  const w = 84,
    h = 24,
    min = Math.min(...data),
    span = Math.max(...data) - min || 1;
  const pts = data
    .map((v, i) => `${(i / Math.max(data.length - 1, 1)) * w},${((v - min) / span) * (h - 4) + 2}`)
    .join(" ");
  return (
    <svg width={w} height={h} aria-hidden="true">
      <polyline points={pts} fill="none" strokeWidth="1.6" stroke={up ? "var(--up)" : "var(--down)"} />
    </svg>
  );
}

function Change({ d }) {
  if (!d) return <span className="muted">–</span>;
  return <span className={d > 0 ? "up" : "down"}>{d > 0 ? "▲" : "▼"} {Math.abs(d)}</span>;
}

function KdBadge({ score }) {
  const kd = getDifficultyInfo(score);
  return (
    <div className="kd-meter">
      <div
        className="kd-pill"
        style={{
          backgroundColor: kd.bg,
          color: kd.text,
          borderColor: kd.border,
        }}
      >
        <span className="kd-dot" style={{ backgroundColor: kd.color }} />
        <span>{kd.score}% {kd.level}</span>
      </div>
      <div className="kd-meter-bar">
        <div
          className="kd-meter-fill"
          style={{ width: `${kd.score}%`, backgroundColor: kd.color }}
        />
      </div>
    </div>
  );
}

function Detail({ row, onClose, onRemove }) {
  const n = row.history.length;
  const kd = getDifficultyInfo(row.difficulty || 40);
  const data = row.history.map((pos, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (n - 1 - i));
    return { day: d.toLocaleDateString("en-IN", { day: "numeric", month: "short" }), pos };
  });

  return (
    <aside className="drawer" role="dialog" aria-label={`History for ${row.keyword}`}>
      <div className="drawer-header">
        <div>
          <h2>{row.keyword}</h2>
          <p className="muted">
            {row.url} · <span style={{ fontWeight: 600, color: "var(--accent)" }}>{row.group}</span>
          </p>
        </div>
        <button className="link" onClick={onClose} style={{ fontSize: "1.1rem" }}>
          ✕
        </button>
      </div>

      <div className="drawer-cards">
        <div className="drawer-card">
          <span className="label">Current Rank</span>
          <span className="value">{formatPosition(cur(row))}</span>
        </div>
        <div className="drawer-card">
          <span className="label">7-Day Change</span>
          <span className="value" style={{ fontSize: "1.15rem" }}>
            <Change d={delta(row)} />
          </span>
        </div>
        <div className="drawer-card">
          <span className="label">Monthly Search Volume</span>
          <span className="value">{row.volume ? row.volume.toLocaleString("en-IN") : "–"}</span>
        </div>
        <div className="drawer-card">
          <span className="label">Difficulty Level</span>
          <span className="value" style={{ color: kd.text, fontSize: "1.15rem" }}>
            {kd.level} ({kd.score}%)
          </span>
        </div>
      </div>

      <div className="kd-box">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: "0.85rem", fontWeight: 600, color: "var(--ink)" }}>
            Keyword Difficulty (KD)
          </span>
          <span
            className="kd-pill"
            style={{
              backgroundColor: kd.bg,
              color: kd.text,
              borderColor: kd.border,
            }}
          >
            <span className="kd-dot" style={{ backgroundColor: kd.color }} />
            {kd.level} · {kd.score}/100
          </span>
        </div>
        <div className="kd-meter-bar" style={{ height: 8 }}>
          <div
            className="kd-meter-fill"
            style={{ width: `${kd.score}%`, backgroundColor: kd.color }}
          />
        </div>
        <p className="muted" style={{ fontSize: "0.82rem" }}>
          {kd.desc}
        </p>
      </div>

      <div>
        <div style={{ fontSize: "0.9rem", fontWeight: 600, marginBottom: 8, color: "var(--ink)" }}>
          30-Day Ranking Position Trend
        </div>
        <div className="chart">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -16 }}>
              <CartesianGrid stroke="var(--line)" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: "var(--mute)" }} minTickGap={24} stroke="var(--line)" />
              <YAxis reversed domain={[1, "dataMax + 5"]} tick={{ fontSize: 11, fill: "var(--mute)" }} stroke="var(--line)" />
              <Tooltip
                formatter={(v) => [`#${v}`, "Rank Position"]}
                contentStyle={{
                  background: "var(--panel)",
                  border: "1px solid var(--line)",
                  borderRadius: 8,
                  color: "var(--ink)",
                  boxShadow: "0 8px 24px rgba(0,0,0,0.5)",
                }}
                labelStyle={{ color: "var(--mute)", marginBottom: 4 }}
                itemStyle={{ color: "var(--ink)", fontWeight: 600 }}
              />
              <Line
                type="monotone"
                dataKey="pos"
                stroke="var(--accent)"
                strokeWidth={2.5}
                dot={{ r: 2, fill: "var(--accent)" }}
                activeDot={{ r: 6, fill: "var(--accent)" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div style={{ marginTop: "auto", paddingTop: 16 }}>
        <button className="danger" style={{ width: "100%" }} onClick={onRemove}>
          Delete Keyword
        </button>
      </div>
    </aside>
  );
}

export default function App() {
  const [rows, setRows] = useState(() => {
    try {
      const s = localStorage.getItem(STORE);
      return s ? JSON.parse(s) : initialKeywords;
    } catch {
      return initialKeywords;
    }
  });

  const [deletedRows, setDeletedRows] = useState(() => {
    try {
      const s = localStorage.getItem(DELETED_STORE);
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  const [projects, setProjects] = useState(() => {
    try {
      const s = localStorage.getItem(PROJECTS_STORE);
      return s ? JSON.parse(s) : initialProjects;
    } catch {
      return initialProjects;
    }
  });

  const [activeProjectId, setActiveProjectId] = useState(() => {
    try {
      const s = localStorage.getItem(ACTIVE_PROJECT_STORE);
      return s || "p1";
    } catch {
      return "p1";
    }
  });

  const [customCategories, setCustomCategories] = useState(() => {
    try {
      const s = localStorage.getItem(CATEGORIES_STORE);
      return s ? JSON.parse(s) : initialCategories;
    } catch {
      return initialCategories;
    }
  });

  const [showProjectDropdown, setShowProjectDropdown] = useState(false);
  const [showAddProjectModal, setShowAddProjectModal] = useState(false);
  const [showAddCategoryModal, setShowAddCategoryModal] = useState(false);

  const [newProjectForm, setNewProjectForm] = useState({ name: "", domain: "" });
  const [newCategoryName, setNewCategoryName] = useState("");

  const [undoToast, setUndoToast] = useState(null); // { item, timer }
  const [showTrashModal, setShowTrashModal] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [view, setView] = useState("list"); // "list" | "add"
  const [tab, setTab] = useState("daily");
  const [q, setQ] = useState("");
  const [group, setGroup] = useState("All");
  const [kdFilter, setKdFilter] = useState("All");
  const [rankFilter, setRankFilter] = useState("All");
  const [sort, setSort] = useState({ key: "position", asc: true });
  const [openId, setOpenId] = useState(null);
  const [editingKeyword, setEditingKeyword] = useState(null);
  const [showQuickModal, setShowQuickModal] = useState(false);
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [bulkText, setBulkText] = useState("");

  const [form, setForm] = useState({
    keyword: "",
    group: "",
    url: "",
    volume: "",
    difficulty: "",
    position: "",
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORE, JSON.stringify(rows));
    } catch {}
  }, [rows]);

  useEffect(() => {
    try {
      localStorage.setItem(DELETED_STORE, JSON.stringify(deletedRows));
    } catch {}
  }, [deletedRows]);

  useEffect(() => {
    try {
      localStorage.setItem(PROJECTS_STORE, JSON.stringify(projects));
    } catch {}
  }, [projects]);

  useEffect(() => {
    try {
      localStorage.setItem(ACTIVE_PROJECT_STORE, activeProjectId);
    } catch {}
  }, [activeProjectId]);

  useEffect(() => {
    try {
      localStorage.setItem(CATEGORIES_STORE, JSON.stringify(customCategories));
    } catch {}
  }, [customCategories]);

  const activeProject =
    projects.find((p) => p.id === activeProjectId) ||
    projects[0] || { id: "p1", name: "TechSphere Cloud", domain: "techsphere.io" };

  const allCategories = useMemo(() => {
    const list = Array.from(
      new Set([...customCategories, ...rows.map((r) => r.group).filter(Boolean)])
    );
    return list;
  }, [customCategories, rows]);

  const groups = useMemo(() => ["All", ...new Set(rows.map((r) => r.group).filter(Boolean))], [rows]);

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      const mG = group === "All" || r.group === group;
      const mQ =
        !q ||
        r.keyword.toLowerCase().includes(q.toLowerCase()) ||
        r.url.toLowerCase().includes(q.toLowerCase());

      const kd = getDifficultyInfo(r.difficulty || 40);
      const mKD =
        kdFilter === "All" ||
        (kdFilter === "Easy" && kd.score <= 29) ||
        (kdFilter === "Medium" && kd.score >= 30 && kd.score <= 49) ||
        (kdFilter === "Hard" && kd.score >= 50 && kd.score <= 69) ||
        (kdFilter === "Very Hard" && kd.score >= 70);

      const p = cur(r);
      const mRank =
        rankFilter === "All" ||
        (rankFilter === "Top 10" && p >= 1 && p <= 10) ||
        (rankFilter === "Top 20" && p >= 11 && p <= 20) ||
        (rankFilter === "Top 30" && p >= 21 && p <= 30) ||
        (rankFilter === "Top 40" && p >= 31 && p <= 40) ||
        (rankFilter === "Top 50" && p >= 41 && p <= 50);

      return mG && mQ && mKD && mRank;
    });
  }, [rows, group, q, kdFilter, rankFilter]);

  const sorted = useMemo(() => {
    const list = [...filtered];
    list.sort((a, b) => {
      let av, bv;
      if (sort.key === "keyword") {
        av = a.keyword.toLowerCase();
        bv = b.keyword.toLowerCase();
      } else if (sort.key === "position") {
        av = cur(a);
        bv = cur(b);
      } else if (sort.key === "change") {
        av = delta(a);
        bv = delta(b);
      } else if (sort.key === "volume") {
        av = a.volume || 0;
        bv = b.volume || 0;
      } else if (sort.key === "difficulty") {
        av = a.difficulty || 0;
        bv = b.difficulty || 0;
      }
      if (av < bv) return sort.asc ? -1 : 1;
      if (av > bv) return sort.asc ? 1 : -1;
      return 0;
    });
    return list;
  }, [filtered, sort]);

  const top3 = rows.filter((r) => cur(r) <= 3).length;
  const top10 = rows.filter((r) => cur(r) <= 10).length;
  const totalVolume = rows.reduce((sum, r) => sum + (Number(r.volume) || 0), 0);
  const avgDifficulty = rows.length
    ? Math.round(rows.reduce((sum, r) => sum + (Number(r.difficulty) || 40), 0) / rows.length)
    : 0;
  const avgKdInfo = getDifficultyInfo(avgDifficulty);

  const handleAdd = (e) => {
    e.preventDefault();
    if (!form.keyword.trim()) return;
    const pos = Math.min(100, Math.max(1, parseInt(form.position, 10) || 50));
    const vol = Math.max(0, parseInt(form.volume, 10) || 1000);
    const diff = Math.min(100, Math.max(1, parseInt(form.difficulty, 10) || 35));

    const newRow = {
      id: Date.now(),
      keyword: form.keyword.trim(),
      group: form.group.trim() || "General",
      url: form.url.trim() || "https://techsphere.io/",
      volume: vol,
      difficulty: diff,
      history: Array(30).fill(pos),
      monthly: {},
    };
    setRows([newRow, ...rows]);
    setForm({ keyword: "", group: "", url: "", volume: "", difficulty: "", position: "" });
    setShowQuickModal(false);
  };

  const handleBulkImport = (e) => {
    e.preventDefault();
    if (!bulkText.trim()) return;

    const lines = bulkText.split("\n").map((l) => l.trim()).filter(Boolean);
    const newKeywords = lines.map((line, idx) => {
      const parts = line.split(",").map((p) => p.trim());
      const kw = parts[0] || line;
      const groupName = parts[1] || "Core Product";
      const vol = parseInt(parts[2], 10) || 1200;
      const diff = parseInt(parts[3], 10) || 35;
      const pos = parseInt(parts[4], 10) || 20;

      return {
        id: Date.now() + idx,
        keyword: kw,
        group: groupName,
        url: "https://techsphere.io/",
        volume: vol,
        difficulty: diff,
        history: Array(30).fill(pos),
        monthly: {},
      };
    });

    setRows([...newKeywords, ...rows]);
    setBulkText("");
    setShowBulkModal(false);
  };

  const handleSaveEdit = (e) => {
    e.preventDefault();
    if (!editingKeyword) return;

    const pos = Math.min(100, Math.max(1, parseInt(editingKeyword.position, 10) || 50));
    const vol = Math.max(0, parseInt(editingKeyword.volume, 10) || 1000);
    const diff = Math.min(100, Math.max(1, parseInt(editingKeyword.difficulty, 10) || 35));

    setRows((prev) =>
      prev.map((r) => {
        if (r.id !== editingKeyword.id) return r;
        const newHistory = [...r.history];
        newHistory[newHistory.length - 1] = pos;
        return {
          ...r,
          keyword: editingKeyword.keyword.trim(),
          group: editingKeyword.group.trim() || "General",
          url: editingKeyword.url.trim() || "https://techsphere.io/",
          volume: vol,
          difficulty: diff,
          history: newHistory,
        };
      })
    );
    setEditingKeyword(null);
  };

  const handleDeleteKeyword = (id, kwName) => {
    const target = rows.find((r) => r.id === id);
    if (!target) return;

    setRows((prev) => prev.filter((r) => r.id !== id));
    setDeletedRows((prev) => [target, ...prev.filter((d) => d.id !== id)]);
    if (openId === id) setOpenId(null);

    if (undoToast?.timer) clearTimeout(undoToast.timer);
    const timer = setTimeout(() => {
      setUndoToast(null);
    }, 6000);
    setUndoToast({ item: target, timer });
  };

  const handleRestore = (item) => {
    setDeletedRows((prev) => prev.filter((d) => d.id !== item.id));
    setRows((prev) => [item, ...prev.filter((r) => r.id !== item.id)]);
    if (undoToast?.item?.id === item.id) {
      if (undoToast.timer) clearTimeout(undoToast.timer);
      setUndoToast(null);
    }
  };

  const handleRestoreAll = () => {
    setRows((prev) => [...deletedRows, ...prev]);
    setDeletedRows([]);
    if (undoToast?.timer) clearTimeout(undoToast.timer);
    setUndoToast(null);
  };

  const handleClearTrash = () => {
    if (window.confirm("Are you sure you want to permanently clear the trash?")) {
      setDeletedRows([]);
      if (undoToast?.timer) clearTimeout(undoToast.timer);
      setUndoToast(null);
    }
  };

  const handleCreateProject = (e) => {
    e.preventDefault();
    if (!newProjectForm.name.trim() || !newProjectForm.domain.trim()) return;
    const cleanDomain = newProjectForm.domain.trim().replace(/^https?:\/\//, "").replace(/\/+$/, "");
    const newP = {
      id: `p-${Date.now()}`,
      name: newProjectForm.name.trim(),
      domain: cleanDomain,
    };
    setProjects((prev) => [...prev, newP]);
    setActiveProjectId(newP.id);
    setNewProjectForm({ name: "", domain: "" });
    setShowAddProjectModal(false);
    setShowProjectDropdown(false);
  };

  const handleCreateCategory = (e) => {
    e.preventDefault();
    const trimmed = newCategoryName.trim();
    if (!trimmed) return;
    if (!customCategories.includes(trimmed)) {
      setCustomCategories((prev) => [...prev, trimmed]);
    }
    setGroup(trimmed);
    setNewCategoryName("");
    setShowAddCategoryModal(false);
  };

  const handleSort = (key) => {
    setSort((prev) => ({
      key,
      asc: prev.key === key ? !prev.asc : true,
    }));
  };

  const openRow = rows.find((r) => r.id === openId);

  return (
    <div className="app-layout">
      {sidebarOpen && (
        <div className="app-sidebar-backdrop" onClick={() => setSidebarOpen(false)} />
      )}

      <aside className={`app-sidebar ${sidebarOpen ? "open" : ""}`}>
        {/* Brand & Project Switcher */}
        <div className="sidebar-brand">
          <button
            className="sidebar-project-btn"
            onClick={() => setShowProjectDropdown((prev) => !prev)}
            title="Switch or Add Project"
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
              <div className="sidebar-logo">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <circle cx="12" cy="12" r="4" />
                </svg>
              </div>
              <div className="sidebar-brand-info">
                <span className="sidebar-brand-name">{activeProject.name}</span>
                <span className="sidebar-brand-sub">{activeProject.domain}</span>
              </div>
            </div>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: "var(--mute)", flexShrink: 0, marginLeft: 6 }}>
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>

          {showProjectDropdown && (
            <div className="sidebar-project-dropdown">
              <div style={{ fontSize: "0.68rem", fontWeight: 700, textTransform: "uppercase", color: "#64748b", padding: "4px 8px 6px" }}>
                Projects ({projects.length})
              </div>
              {projects.map((proj) => (
                <button
                  key={proj.id}
                  className={`sidebar-project-item ${proj.id === activeProjectId ? "active" : ""}`}
                  onClick={() => {
                    setActiveProjectId(proj.id);
                    setShowProjectDropdown(false);
                  }}
                >
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontWeight: 600, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{proj.name}</div>
                    <div style={{ fontSize: "0.72rem", color: "var(--mute)" }}>{proj.domain}</div>
                  </div>
                  {proj.id === activeProjectId && <span style={{ color: "var(--accent)", marginLeft: 6 }}>✓</span>}
                </button>
              ))}
              <button
                className="sidebar-add-project-btn"
                onClick={() => {
                  setShowAddProjectModal(true);
                  setShowProjectDropdown(false);
                }}
              >
                <span>+</span> Add Project
              </button>
            </div>
          )}
        </div>

        {/* Primary CTA button */}
        <div className="sidebar-action-wrap">
          <button
            className="sidebar-primary-cta"
            onClick={() => {
              setView("add");
              setSidebarOpen(false);
            }}
          >
            <span className="cta-plus">+</span>
            <span>Add Keyword</span>
          </button>
        </div>

        {/* Views & Trends */}
        <div className="sidebar-section">
          <div className="sidebar-section-title">Views & Trends</div>
          <nav className="sidebar-nav">
            <button
              className={`sidebar-nav-item ${view === "list" && tab === "daily" ? "active" : ""}`}
              onClick={() => {
                setView("list");
                setTab("daily");
                setSidebarOpen(false);
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
              </svg>
              <span>Daily Trend</span>
            </button>

            <button
              className={`sidebar-nav-item ${view === "list" && tab === "monthly" ? "active" : ""}`}
              onClick={() => {
                setView("list");
                setTab("monthly");
                setSidebarOpen(false);
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                <line x1="16" x2="16" y1="2" y2="6" />
                <line x1="8" x2="8" y1="2" y2="6" />
                <line x1="3" x2="21" y1="10" y2="10" />
              </svg>
              <span>Monthly Comparison</span>
            </button>
          </nav>
        </div>

        {/* Categories Section */}
        <div className="sidebar-section">
          <div className="sidebar-section-header">
            <span className="sidebar-section-title">Categories</span>
            <button
              className="sidebar-mini-add-btn"
              onClick={() => setShowAddCategoryModal(true)}
              title="Create new category"
            >
              + Add
            </button>
          </div>
          <nav className="sidebar-nav sidebar-categories-nav">
            <button
              className={`sidebar-nav-item ${group === "All" ? "active" : ""}`}
              onClick={() => {
                setGroup("All");
                setView("list");
                setSidebarOpen(false);
              }}
            >
              <span className="category-dot" style={{ background: group === "All" ? "var(--accent)" : "#475569" }} />
              <span className="category-text">All Categories</span>
              <span className="category-count">{rows.length}</span>
            </button>

            {allCategories.map((cat) => {
              const count = rows.filter((r) => r.group === cat).length;
              return (
                <button
                  key={cat}
                  className={`sidebar-nav-item ${group === cat ? "active" : ""}`}
                  onClick={() => {
                    setGroup(cat);
                    setView("list");
                    setSidebarOpen(false);
                  }}
                >
                  <span className="category-dot" />
                  <span className="category-text">{cat}</span>
                  <span className="category-count">{count}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Quick Actions */}
        <div className="sidebar-section">
          <div className="sidebar-section-title">Quick Actions</div>
          <nav className="sidebar-nav">
            <button
              className="sidebar-nav-item"
              onClick={() => {
                setShowAddProjectModal(true);
                setSidebarOpen(false);
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect width="18" height="18" x="3" y="3" rx="2" />
                <path d="M9 3v18" />
                <path d="M14 9h3" />
                <path d="M14 14h3" />
              </svg>
              <span>+ Add Project</span>
            </button>

            <button
              className="sidebar-nav-item"
              onClick={() => {
                setShowAddCategoryModal(true);
                setSidebarOpen(false);
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z" />
                <line x1="12" x2="12" y1="10" y2="16" />
                <line x1="9" x2="15" y1="13" y2="13" />
              </svg>
              <span>+ Add Category</span>
            </button>

            <button
              className="sidebar-nav-item"
              onClick={() => {
                setShowQuickModal((prev) => !prev);
                setSidebarOpen(false);
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
              </svg>
              <span>Quick Modal</span>
            </button>

            <button
              className="sidebar-nav-item"
              onClick={() => {
                setShowBulkModal(true);
                setSidebarOpen(false);
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/>
                <path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>
                <path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/>
              </svg>
              <span>Bulk Import</span>
            </button>

            <button
              className="sidebar-nav-item"
              onClick={() => {
                setShowTrashModal(true);
                setSidebarOpen(false);
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 6h18" />
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
              </svg>
              <span>Trash</span>
              {deletedRows.length > 0 && <span className="trash-badge">{deletedRows.length}</span>}
            </button>
          </nav>
        </div>

        <div className="sidebar-stats-widget">
          <div className="sidebar-stats-header">
            <span>Portfolio Health</span>
            <span className="sidebar-live-pill">● Live</span>
          </div>
          <div className="sidebar-stats-grid">
            <div className="sidebar-stat-cell">
              <span className="sidebar-stat-label">Total</span>
              <span className="sidebar-stat-val">{rows.length}</span>
            </div>
            <div className="sidebar-stat-cell">
              <span className="sidebar-stat-label">Top 3</span>
              <span className="sidebar-stat-val" style={{ color: "var(--up)" }}>{top3}</span>
            </div>
            <div className="sidebar-stat-cell">
              <span className="sidebar-stat-label">Top 10</span>
              <span className="sidebar-stat-val" style={{ color: "var(--accent)" }}>{top10}</span>
            </div>
            <div className="sidebar-stat-cell">
              <span className="sidebar-stat-label">Avg KD</span>
              <span className="sidebar-stat-val" style={{ color: avgKdInfo.color }}>{avgDifficulty}%</span>
            </div>
          </div>
        </div>
      </aside>

      <div className="app-main-content">
        <div className="mobile-topbar">
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div className="sidebar-logo" style={{ width: 28, height: 28, borderRadius: 6 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <circle cx="12" cy="12" r="10" />
                <circle cx="12" cy="12" r="4" />
              </svg>
            </div>
            <span style={{ fontWeight: 700, fontSize: "0.95rem" }}>RankPulse</span>
          </div>
          <button className="mobile-toggle-btn" onClick={() => setSidebarOpen(!sidebarOpen)}>
            ☰
          </button>
        </div>

        <main>
          {view === "add" ? (
            <AddKeywordView
              onBack={() => setView("list")}
              onAdd={(newKw) => setRows([newKw, ...rows])}
              defaultDomain={activeProject.domain}
              availableCategories={allCategories}
            />
          ) : (
            <>
              <header className="main-header">
                <div>
                  <h1>Keyword Intelligence & SERP Tracker</h1>
                  <p className="muted">
                    Monitor real-time Google search positions, historical sparklines, and monthly variance for <span style={{ color: "var(--accent)", fontWeight: 600 }}>{activeProject.domain}</span>.
                  </p>
                </div>
                <div className="header-actions">
                  <button
                    className="btn-header-ghost"
                    onClick={() => setShowTrashModal(true)}
                    title="View recently deleted keywords"
                  >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M3 6h18" />
                      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                      <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                    </svg>
                    <span>Trash</span>
                    {deletedRows.length > 0 && <span className="trash-badge">{deletedRows.length}</span>}
                  </button>
                  <button className="btn-header-ghost" onClick={() => setShowBulkModal(true)}>
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/>
                      <path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>
                      <path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/>
                    </svg>
                    <span>Bulk Import</span>
                  </button>
                  <button
                    className="btn-header-outline"
                    onClick={() => setShowQuickModal((prev) => !prev)}
                  >
                    Quick Modal
                  </button>
                  <button className="btn-header-primary" onClick={() => setView("add")}>
                    <span>+</span> Add Keyword
                  </button>
                </div>
              </header>

          <div className="tabs">
            <button
              className={`tab-btn ${tab === "daily" ? "active" : ""}`}
              onClick={() => setTab("daily")}
            >
              Daily Trend
            </button>
            <button
              className={`tab-btn ${tab === "monthly" ? "active" : ""}`}
              onClick={() => setTab("monthly")}
            >
              Monthly Comparison
            </button>
          </div>

          <div className="stats">
            <div>
              <b>{rows.length}</b>
              <span>Total Keywords</span>
            </div>
            <div>
              <b>{top3}</b>
              <span>Top 3 Rankings</span>
            </div>
            <div>
              <b>{top10}</b>
              <span>Top 10 Rankings</span>
            </div>
            <div>
              <b>{formatVolume(totalVolume)}</b>
              <span>Total Search Volume</span>
            </div>
            <div>
              <b style={{ color: avgKdInfo.color }}>{avgDifficulty}%</b>
              <span>Avg KD ({avgKdInfo.level})</span>
            </div>
          </div>

          {tab === "monthly" ? (
            <Monthly rows={rows} setRows={setRows} />
          ) : (
            <>
              {showQuickModal && (
                <form className="add" onSubmit={handleAdd}>
                  <div className="add-header">+ Track New Keyword</div>
                  <input
                    placeholder="Keyword (e.g. nextjs seo)"
                    required
                    value={form.keyword}
                    onChange={(e) => setForm({ ...form, keyword: e.target.value })}
                  />
                  <input
                    placeholder="Category / Group"
                    value={form.group}
                    onChange={(e) => setForm({ ...form, group: e.target.value })}
                  />
                  <input
                    placeholder="Page URL (/guides/...)"
                    value={form.url}
                    onChange={(e) => setForm({ ...form, url: e.target.value })}
                  />
                  <input
                    type="number"
                    min="0"
                    placeholder="Vol (e.g. 5000)"
                    value={form.volume}
                    onChange={(e) => setForm({ ...form, volume: e.target.value })}
                  />
                  <input
                    type="number"
                    min="1"
                    max="100"
                    placeholder="KD% (1-100)"
                    value={form.difficulty}
                    onChange={(e) => setForm({ ...form, difficulty: e.target.value })}
                  />
                  <input
                    type="number"
                    min="1"
                    max="100"
                    placeholder="Pos (1-100)"
                    value={form.position}
                    onChange={(e) => setForm({ ...form, position: e.target.value })}
                  />
                  <button className="primary" type="submit">
                    + Add
                  </button>
                </form>
              )}

              <div className="toolbar">
                <div className="toolbar-search-wrap">
                  <svg
                    className="search-icon"
                    width="15"
                    height="15"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <circle cx="11" cy="11" r="8" />
                    <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  </svg>
                  <input
                    placeholder="Search keywords or URLs..."
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                  />
                </div>

                <div className="toolbar-filters-group">
                  <div className="chips">
                    <span className="chip-label">Difficulty:</span>
                    {["All", "Easy", "Medium", "Hard", "Very Hard"].map((lvl) => (
                      <button
                        key={lvl}
                        className={`chip ${kdFilter === lvl ? "on" : ""}`}
                        onClick={() => setKdFilter(lvl)}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>

                  <div className="toolbar-divider" />

                  <div className="chips">
                    <span className="chip-label">Rank:</span>
                    {["All", "Top 10", "Top 20", "Top 30", "Top 40", "Top 50"].map((rf) => (
                      <button
                        key={rf}
                        className={`chip ${rankFilter === rf ? "on" : ""}`}
                        onClick={() => setRankFilter(rf)}
                      >
                        {rf}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="tablewrap">
                <table>
                  <thead>
                    <tr>
                      <th className="sortable" onClick={() => handleSort("keyword")}>
                        Keyword {sort.key === "keyword" ? (sort.asc ? "▲" : "▼") : ""}
                      </th>
                      <th className="sortable" onClick={() => handleSort("position")}>
                        Position {sort.key === "position" ? (sort.asc ? "▲" : "▼") : ""}
                      </th>
                      <th className="sortable" onClick={() => handleSort("change")}>
                        7d Change {sort.key === "change" ? (sort.asc ? "▲" : "▼") : ""}
                      </th>
                      <th className="sortable" onClick={() => handleSort("volume")}>
                        Search Volume {sort.key === "volume" ? (sort.asc ? "▲" : "▼") : ""}
                      </th>
                      <th className="sortable" onClick={() => handleSort("difficulty")}>
                        Difficulty (KD) {sort.key === "difficulty" ? (sort.asc ? "▲" : "▼") : ""}
                      </th>
                      <th>30d Trend</th>
                      <th>Target URL</th>
                      <th style={{ textAlign: "right", paddingRight: 16 }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sorted.map((r) => (
                      <tr key={r.id} onClick={() => setOpenId(r.id)}>
                        <td>
                          <b>{r.keyword}</b>
                          <div className="muted">{r.group}</div>
                        </td>
                        <td className="pos">{formatPosition(cur(r))}</td>
                        <td>
                          <Change d={delta(r)} />
                        </td>
                        <td className="vol-cell">
                          {r.volume ? r.volume.toLocaleString("en-IN") : "–"}
                          <div className="vol-sub">/ month</div>
                        </td>
                        <td>
                          <KdBadge score={r.difficulty || 40} />
                        </td>
                        <td>
                          <Spark data={r.history} up={delta(r) >= 0} />
                        </td>
                        <td className="muted">{r.url}</td>
                        <td className="actions-cell" onClick={(e) => e.stopPropagation()}>
                          <div className="actions-wrap">
                            <button
                              className="action-btn view-btn"
                              title="View details & trends"
                              onClick={() => setOpenId(r.id)}
                            >
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
                                <circle cx="12" cy="12" r="3" />
                              </svg>
                              <span>View</span>
                            </button>
                            <button
                              className="action-btn edit-btn"
                              title="Edit keyword"
                              onClick={() => setEditingKeyword({ ...r, position: cur(r) })}
                            >
                              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" />
                              </svg>
                              <span>Edit</span>
                            </button>
                            <button
                              className="action-btn delete-btn"
                              title="Delete keyword"
                              onClick={() => handleDeleteKeyword(r.id, r.keyword)}
                            >
                              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M3 6h18" />
                                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                                <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                              </svg>
                              <span>Delete</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {!sorted.length && (
                  <p className="empty">No matching keywords found. Try changing your search or filters.</p>
                )}
              </div>
            </>
          )}

          {openRow && (
            <Detail
              row={openRow}
              onClose={() => setOpenId(null)}
              onRemove={() => handleDeleteKeyword(openRow.id, openRow.keyword)}
            />
          )}

          {editingKeyword && (
            <div className="modal-overlay" onClick={() => setEditingKeyword(null)}>
              <div className="modal-card" onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                  <h2 className="modal-title">Edit Keyword</h2>
                  <button className="link" onClick={() => setEditingKeyword(null)}>
                    ✕
                  </button>
                </div>
                <form onSubmit={handleSaveEdit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  <div className="form-group">
                    <label className="form-label">Keyword Query *</label>
                    <input
                      required
                      value={editingKeyword.keyword}
                      onChange={(e) =>
                        setEditingKeyword({ ...editingKeyword, keyword: e.target.value })
                      }
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Category / Group</label>
                    <input
                      value={editingKeyword.group}
                      onChange={(e) =>
                        setEditingKeyword({ ...editingKeyword, group: e.target.value })
                      }
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Target Landing Page URL</label>
                    <input
                      value={editingKeyword.url}
                      onChange={(e) =>
                        setEditingKeyword({ ...editingKeyword, url: e.target.value })
                      }
                    />
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                    <div className="form-group">
                      <label className="form-label">Search Volume</label>
                      <input
                        type="number"
                        min="0"
                        value={editingKeyword.volume}
                        onChange={(e) =>
                          setEditingKeyword({ ...editingKeyword, volume: e.target.value })
                        }
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">KD % (1-100)</label>
                      <input
                        type="number"
                        min="1"
                        max="100"
                        value={editingKeyword.difficulty}
                        onChange={(e) =>
                          setEditingKeyword({ ...editingKeyword, difficulty: e.target.value })
                        }
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Position (1-100)</label>
                      <input
                        type="number"
                        min="1"
                        max="101"
                        value={editingKeyword.position}
                        onChange={(e) =>
                          setEditingKeyword({ ...editingKeyword, position: e.target.value })
                        }
                      />
                    </div>
                  </div>

                  <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 8 }}>
                    <button
                      type="button"
                      className="btn-cancel"
                      onClick={() => setEditingKeyword(null)}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="primary">
                      Save Changes
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {showBulkModal && (
            <div className="modal-overlay" onClick={() => setShowBulkModal(false)}>
              <div className="modal-card" onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                  <h2 className="modal-title">Bulk Import Keywords</h2>
                  <button className="link" onClick={() => setShowBulkModal(false)}>
                    ✕
                  </button>
                </div>
                <p className="muted" style={{ fontSize: "0.85rem" }}>
                  Paste keywords below (one per line, or format: <code>keyword, group, volume, kd, position</code>):
                </p>
                <form onSubmit={handleBulkImport}>
                  <textarea
                    rows={6}
                    style={{ width: "100%", marginBottom: 14 }}
                    placeholder={`distributed sql query engine, Core Product, 1400, 35, 3\ncloud data warehouse, Core Product, 8200, 55, 12\nreal time analytics, Guides, 3400, 42, 8`}
                    value={bulkText}
                    onChange={(e) => setBulkText(e.target.value)}
                    required
                  />
                  <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
                    <button
                      type="button"
                      className="btn-cancel"
                      onClick={() => setShowBulkModal(false)}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="primary">
                      Import Keywords
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Undo Toast Notification */}
          {undoToast && (
            <div className="undo-toast" role="status">
              <span>
                Deleted <b>"{undoToast.item.keyword}"</b>
              </span>
              <button className="undo-btn" onClick={() => handleRestore(undoToast.item)}>
                Undo
              </button>
              <button
                className="link"
                style={{ fontSize: "0.9rem", color: "var(--mute)" }}
                onClick={() => {
                  if (undoToast.timer) clearTimeout(undoToast.timer);
                  setUndoToast(null);
                }}
              >
                ✕
              </button>
            </div>
          )}

          {/* Trash / Recently Deleted Modal */}
          {showTrashModal && (
            <div className="modal-overlay" onClick={() => setShowTrashModal(false)}>
              <div className="modal-card" style={{ maxWidth: 540 }} onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                  <h2 className="modal-title">
                    Recently Deleted Keywords ({deletedRows.length})
                  </h2>
                  <button className="link" onClick={() => setShowTrashModal(false)}>
                    ✕
                  </button>
                </div>
                <p className="muted" style={{ fontSize: "0.85rem", marginTop: -6, marginBottom: 12 }}>
                  Keywords in trash can be restored back to your tracking list anytime.
                </p>

                {deletedRows.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "32px 16px", color: "var(--mute)" }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ margin: "0 auto 8px", opacity: 0.6 }}>
                      <path d="M3 6h18" />
                      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
                      <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
                    </svg>
                    <p>No deleted keywords in trash.</p>
                  </div>
                ) : (
                  <>
                    <div className="trash-list">
                      {deletedRows.map((item) => (
                        <div key={item.id} className="trash-item">
                          <div>
                            <div style={{ fontWeight: 600, color: "var(--ink)" }}>{item.keyword}</div>
                            <div className="muted" style={{ fontSize: "0.78rem" }}>
                              {item.group} · {formatPosition(cur(item))} · Vol: {formatVolume(item.volume || 0)}
                            </div>
                          </div>
                          <button
                            className="trash-restore-btn"
                            onClick={() => handleRestore(item)}
                            title="Restore this keyword"
                          >
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                              <path d="M3 3v5h5" />
                            </svg>
                            Restore
                          </button>
                        </div>
                      ))}
                    </div>

                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 14, paddingTop: 10, borderTop: "1px solid var(--line)" }}>
                      <button
                        type="button"
                        className="btn-cancel"
                        style={{ color: "#f43f5e" }}
                        onClick={handleClearTrash}
                      >
                        Clear Trash
                      </button>
                      <div style={{ display: "flex", gap: 10 }}>
                        <button
                          type="button"
                          className="btn-cancel"
                          onClick={() => setShowTrashModal(false)}
                        >
                          Close
                        </button>
                        <button
                          type="button"
                          className="primary"
                          onClick={handleRestoreAll}
                        >
                          Restore All ({deletedRows.length})
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Add Project Modal */}
          {showAddProjectModal && (
            <div className="modal-overlay" onClick={() => setShowAddProjectModal(false)}>
              <div className="modal-card" style={{ maxWidth: 480 }} onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                  <h2 className="modal-title">+ Add New Project</h2>
                  <button className="link" onClick={() => setShowAddProjectModal(false)}>
                    ✕
                  </button>
                </div>
                <p className="muted" style={{ fontSize: "0.85rem", marginTop: -6, marginBottom: 14 }}>
                  Create a new workspace to track keyword rankings for another domain.
                </p>
                <form onSubmit={handleCreateProject} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  <div className="form-group">
                    <label className="form-label">Project Name *</label>
                    <input
                      required
                      placeholder="e.g. Acme SaaS Platform"
                      value={newProjectForm.name}
                      onChange={(e) => setNewProjectForm({ ...newProjectForm, name: e.target.value })}
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Target Website / Domain *</label>
                    <input
                      required
                      placeholder="e.g. acme.com or datamesh.io"
                      value={newProjectForm.domain}
                      onChange={(e) => setNewProjectForm({ ...newProjectForm, domain: e.target.value })}
                    />
                  </div>
                  <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 8 }}>
                    <button
                      type="button"
                      className="btn-cancel"
                      onClick={() => setShowAddProjectModal(false)}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="primary">
                      Create Project
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Add Category Modal */}
          {showAddCategoryModal && (
            <div className="modal-overlay" onClick={() => setShowAddCategoryModal(false)}>
              <div className="modal-card" style={{ maxWidth: 440 }} onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                  <h2 className="modal-title">+ Add New Category</h2>
                  <button className="link" onClick={() => setShowAddCategoryModal(false)}>
                    ✕
                  </button>
                </div>
                <p className="muted" style={{ fontSize: "0.85rem", marginTop: -6, marginBottom: 14 }}>
                  Group keywords by product pillars, topic clusters, or landing pages.
                </p>
                <form onSubmit={handleCreateCategory} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  <div className="form-group">
                    <label className="form-label">Category Name *</label>
                    <input
                      required
                      placeholder="e.g. Integrations, Pricing, Competitors..."
                      value={newCategoryName}
                      onChange={(e) => setNewCategoryName(e.target.value)}
                    />
                  </div>
                  <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 8 }}>
                    <button
                      type="button"
                      className="btn-cancel"
                      onClick={() => setShowAddCategoryModal(false)}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="primary">
                      Create Category
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </>
      )}
        </main>
      </div>
    </div>
  );
}
